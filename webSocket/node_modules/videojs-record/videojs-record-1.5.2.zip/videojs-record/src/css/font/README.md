Font
====

This directory contains the additional font used in the videojs-record plugin.

Edit the Font
-------------

To modify the generated font, change the `icons.json` file, located in the `src/css/font`
directory. Run `grunt font` to update the generated font files. View
`src/css/font/preview.html` in a browser to see the result.

See the videojs `font` project documentation for more info:
https://github.com/videojs/font/blob/master/README.md
